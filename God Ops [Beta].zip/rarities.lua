SMODS.Rarity {
    key = "the_one_above_all",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('070083'),
    loc_txt = {
        name = "The One above all."
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "finality",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.026,
    badge_colour = HEX('d0021b'),
    loc_txt = {
        name = "Finality"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "gods",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.049,
    badge_colour = HEX('9013fe'),
    loc_txt = {
        name = "Gods"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ssummon",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('160050'),
    loc_txt = {
        name = "Saur's Summon."
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "e0summon",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('4c4c4c'),
    loc_txt = {
        name = "ENTITY0's Summon"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}