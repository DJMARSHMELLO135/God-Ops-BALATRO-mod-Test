SMODS.Joker{ --ANTIGOD, THE ADVERSARY.
    key = "antigodtheadversary",
    config = {
        extra = {
            hand_change = 6,
            debt_amount = 66,
            odds = 1,
            Xmult = 6,
            odds2 = 6,
            mult = 16
        }
    },
    loc_txt = {
        ['name'] = 'ANTIGOD, THE ADVERSARY.',
        ['text'] = {
            [1] = '{C:dark_edition}The Antigod shall{}{C:hearts} end reality.{}',
            [2] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4666,
    rarity = "godopsbe_finality",
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godopsbe_godops"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local allMatchRank = true
    for i, c in ipairs(context.full_hand) do
        if not (c:get_id() == 6) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.full_hand > 0
end)() then
                if SMODS.pseudorandom_probability(card, 'group_0_19d2f5f7', 1, card.ability.extra.odds, 'j_godopsbe_antigodtheadversary', false) then
              SMODS.calculate_effect({Xmult = card.ability.extra.Xmult}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "THE ANTIGOD GRANTS YOU POWER.", colour = G.C.WHITE})
          end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_963877b5', 1, card.ability.extra.odds, 'j_godopsbe_antigodtheadversary', true) then
              SMODS.calculate_effect({mult = card.ability.extra.mult}, card)
          end
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.extra.hand_change
        card.ability.extra.original_hand_size = G.hand.config.card_limit
        local difference = 16 - G.hand.config.card_limit
        G.hand:change_size(difference)
        G.GAME.bankrupt_at = G.GAME.bankrupt_at - card.ability.extra.debt_amount
        -- Showman effect enabled (allow duplicate cards)
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands - card.ability.extra.hand_change
        if card.ability.extra.original_hand_size then
            local difference = card.ability.extra.original_hand_size - G.hand.config.card_limit
            G.hand:change_size(difference)
        end
        G.GAME.bankrupt_at = G.GAME.bankrupt_at + card.ability.extra.debt_amount
        -- Showman effect disabled
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_godopsbe_antigodtheadversary" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end


local smods_showman_ref = SMODS.showman
function SMODS.showman(card_key)
    if next(SMODS.find_card("j_godopsbe_antigodtheadversary")) then
        return true
    end
    return smods_showman_ref(card_key)
end