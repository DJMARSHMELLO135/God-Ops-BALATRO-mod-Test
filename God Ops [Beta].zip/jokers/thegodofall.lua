SMODS.Joker{ --THE GOD OF ALL.
    key = "thegodofall",
    config = {
        extra = {
            dollars = 1111111,
            chips = 9999999,
            mult = 9999,
            emult = 555,
            Xmult = 55
        }
    },
    loc_txt = {
        ['name'] = 'THE GOD OF ALL.',
        ['text'] = {
            [1] = '{C:dark_edition}Infinite power.{}',
            [2] = '{C:spades}You will never fail again.{}',
            [3] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 99999999999999,
    rarity = "godopsbe_the_one_above_all",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godopsbe_godops_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'sou' 
          or args.source == 'rif' or args.source == 'rta' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    func = function()
                    local target_amount = card.ability.extra.dollars
                    local current_amount = G.GAME.dollars
                    local difference = target_amount - current_amount
                    ease_dollars(difference)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to $"..tostring(card.ability.extra.dollars), colour = G.C.MONEY})
                    return true
                end,
                    extra = {
                        chips = card.ability.extra.chips,
                        colour = G.C.CHIPS,
                        extra = {
                            mult = card.ability.extra.mult,
                        extra = {
                            e_mult = card.ability.extra.emult,
                            message = "The GOD OF ALL empowers you.",
                            colour = G.C.DARK_EDITION,
                        extra = {
                            Xmult = card.ability.extra.Xmult
                        }
                        }
                        }
                        }
                }
        end
        if context.selling_self  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "YOU ABSOLUTE IDIOT.", colour = G.C.RED})
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.5,
                    func = function()
                        if G.STAGE == G.STAGES.RUN then 
                          G.STATE = G.STATES.GAME_OVER
                          G.STATE_COMPLETE = false
                        end
                    end
                }))
                
                return true
            end
                }
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_godopsbe_thegodofall" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end