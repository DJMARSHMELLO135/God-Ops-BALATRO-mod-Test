SMODS.Joker{ --True Insanity
    key = "trueinsanity",
    config = {
        extra = {
            chips_min = 1,
            chips_max = 166,
            mult_min = 1,
            mult_max = 11.11,
            odds = 666,
            yes = 0,
            var1 = 0,
            eternal = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'True Insanity',
        ['text'] = {
            [1] = '{C:spades}+1 -> +166 Chips{}',
            [2] = '{C:spades} +1 -> +6.6 Multiplier{}',
            [3] = '{C:spades}1 in 666 chance to become a fallen god.{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 101,
    rarity = "godopsbe_gods",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godopsbe_godops_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    chips = pseudorandom('chips_70059806', card.ability.extra.chips_min, card.ability.extra.chips_max),
                    extra = {
                        mult = pseudorandom('mult_8773864c', card.ability.extra.mult_min, card.ability.extra.mult_max)
                        }
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_501d285c', 1, card.ability.extra.odds, 'j_godopsbe_trueinsanity', true) then
              local target_joker = nil
                for i, joker in ipairs(G.jokers.cards) do
                    if joker.config.center.key == "j_trueinsanity" and not joker.getting_sliced then
                        target_joker = joker
                        break
                    end
                end
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
                        local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_corruptedtrueinsanity' })
                          if joker_card then
                              
                              joker_card:add_sticker('eternal', true)
                          end
                          
                          return true
                      end
                  }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
          end
                        return true
                    end
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Showman effect enabled (allow duplicate cards)
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Showman effect disabled
    end
}


local smods_showman_ref = SMODS.showman
function SMODS.showman(card_key)
    if next(SMODS.find_card("j_godopsbe_trueinsanity")) then
        return true
    end
    return smods_showman_ref(card_key)
end