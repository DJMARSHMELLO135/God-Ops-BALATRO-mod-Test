SMODS.Joker{ --W.D. Gaster
    key = "wdgaster",
    config = {
        extra = {
            debt_amount = 22,
            mult = 1.25,
            mult2 = 1.25,
            mult3 = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'W.D. Gaster',
        ['text'] = {
            [1] = '{C:spades}Allows you to go into -22 max debt.{}',
            [2] = '{C:spades}+1.25 Multiplier per God(+) joker in deck.{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 88,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godopsbe_godops_jokers"] = true },

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    local count = 0
    for _, joker_owned in pairs(G.jokers.cards or {}) do
        if joker_owned.config.center.rarity == "godopsbe_gods" then
            count = count + 1
        end
    end
    return count == 1
end)() then
                return {
                    mult = card.ability.extra.mult
                }
            elseif (function()
    local count = 0
    for _, joker_owned in pairs(G.jokers.cards or {}) do
        if joker_owned.config.center.rarity == "godopsbe_finality" then
            count = count + 1
        end
    end
    return count == 1
end)() then
                return {
                    mult = card.ability.extra.mult2
                }
            elseif (function()
    local count = 0
    for _, joker_owned in pairs(G.jokers.cards or {}) do
        if joker_owned.config.center.rarity == "godopsbe_the_one_above_all" then
            count = count + 1
        end
    end
    return count == 1
end)() then
                return {
                    mult = card.ability.extra.mult3
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.GAME.bankrupt_at = G.GAME.bankrupt_at - card.ability.extra.debt_amount
        -- Showman effect enabled (allow duplicate cards)
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.GAME.bankrupt_at = G.GAME.bankrupt_at + card.ability.extra.debt_amount
        -- Showman effect disabled
    end
}


local smods_showman_ref = SMODS.showman
function SMODS.showman(card_key)
    if next(SMODS.find_card("j_godopsbe_wdgaster")) then
        return true
    end
    return smods_showman_ref(card_key)
end