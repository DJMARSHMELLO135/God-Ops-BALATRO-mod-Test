SMODS.Joker{ --VIRUS404
    key = "virus404",
    config = {
        extra = {
            chips_min = 40.4,
            chips_max = 404,
            mult_min = 0,
            mult_max = 4.4,
            odds = 40.4,
            godops_malwareinfused = 0
        }
    },
    loc_txt = {
        ['name'] = 'VIRUS404',
        ['text'] = {
            [1] = '{C:hearts}Grants 0 -> 4.04 multiplier.{}',
            [2] = '{C:hearts}Grants 40.4 -> 404 Chips.{}',
            [3] = '{C:hearts}1 in 40.4 Chance to grant Malware Infused to a random played card.{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 303,
    rarity = "godopsbe_gods",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godopsbe_godops"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = pseudorandom('chips_4a3e260b', card.ability.extra.chips_min, card.ability.extra.chips_max),
                    message = "MALWARE!",
                    extra = {
                        mult = pseudorandom('mult_c559e843', card.ability.extra.mult_min, card.ability.extra.mult_max)
                        }
                }
        end
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_5619d98f', 1, card.ability.extra.odds, 'j_godopsbe_virus404', false) then
              context.other_card:set_seal("godops_malwareinfused", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "MALWARE!", colour = G.C.BLUE})
          end
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Showman effect enabled (allow duplicate cards)
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Showman effect disabled
    end
}


local smods_showman_ref = SMODS.showman
function SMODS.showman(card_key)
    if next(SMODS.find_card("j_godopsbe_virus404")) then
        return true
    end
    return smods_showman_ref(card_key)
end