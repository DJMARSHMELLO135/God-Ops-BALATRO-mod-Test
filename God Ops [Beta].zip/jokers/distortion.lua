SMODS.Joker{ --DISTORTION!
    key = "distortion",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'DISTORTION!',
        ['text'] = {
            [1] = 'A {C:blue}custom{} joker with {C:red}unique{} effects.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godopsbe_godopsno_jokers"] = true },

    calculate = function(self, card, context)
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Showman effect enabled (allow duplicate cards)
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Showman effect disabled
    end
}


local smods_showman_ref = SMODS.showman
function SMODS.showman(card_key)
    if next(SMODS.find_card("j_godopsbe_distortion")) then
        return true
    end
    return smods_showman_ref(card_key)
end