SMODS.Joker{ --SAUR
    key = "saur",
    config = {
        extra = {
            odds = 5,
            odds2 = 55,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'SAUR',
        ['text'] = {
            [1] = '{C:dark_edition}1/5 Chance to summon a SAUR STAFF{}',
            [2] = '{C:dark_edition}1/55 Chance to summon a Empowered Staff of the Observer{}',
            [3] = '{C:spades}+11 Multi per Saur Staff in Jokers{}',
            [4] = '{C:spades}+55 Multi and +555 chips per Empowered Staff of the Observer{}',
            [5] = 'Summons do not take up joker space.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 333,
    rarity = "godops_gods",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godops_godops_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_3a6650a5', 1, card.ability.extra.odds, 'j_godops_saur', false) then
              local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_godops_saurstaff' })
                          if joker_card then
                              joker_card:set_edition("e_negative", true)
                              
                          end
                          
                          return true
                      end
                  }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Summoned!", colour = G.C.BLUE})
          end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_80da7243', 1, card.ability.extra.odds, 'j_godops_saur', false) then
              local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_godops_esoto' })
                          if joker_card then
                              joker_card:set_edition("e_negative", true)
                              
                          end
                          
                          return true
                      end
                  }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Summoned!", colour = G.C.BLUE})
          end
            end
        end
    end
}