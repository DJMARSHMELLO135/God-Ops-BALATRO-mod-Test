SMODS.Joker{ --Corrupted Insanity
    key = "ci",
    config = {
        extra = {
            chips = 77,
            mult = 7
        }
    },
    loc_txt = {
        ['name'] = 'Corrupted Insanity',
        ['text'] = {
            [1] = 'The easiest way into the God Ops mod.',
            [2] = '{C:spades}+7 Multiplier{}',
            [3] = '{C:spades}+77 Chips{}',
            [4] = '',
            [5] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 55,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godops_godops_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                        }
                }
        end
    end
}