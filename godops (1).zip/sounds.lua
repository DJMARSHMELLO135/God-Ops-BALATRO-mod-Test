SMODS.Sound{
    key="malwareinfusedsound",
    path="malwareinfusedsound.ogg",
    pitch=0.7,
    volume=0.6
}