SMODS.Booster {
    key = 'fragmented_reality',
    loc_txt = {
        name = "Fragmented Reality",
        text = {
            "Something draws near, intrigued by your skills of surviving with vessels.",
            "...You may want to-",
            "Kidding. Just me.",
            "Ah, I see you want to entertain me by yourself.",
            "  Ill accept your offer. Best of luck to you, player.",
            "... Lets get right down to buisness then."
        },
        group_name = "godops_boosters"
    },
    config = { extra = 1, choose = 1 },
    cost = 99999,
    weight = 0.25,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    kind = 'DIVINE.',
    group_key = "godops_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        key = "goa",
        set = "Joker",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "godops_fragmented_reality"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("5a5a5a"))
        ease_background_colour({ new_colour = HEX('5a5a5a'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'winner_pack',
    loc_txt = {
        name = "WINNER PACK",
        text = {
            "This pack will contain custom cards for whoever",
            "gets the GOA card first!",
            "For now contains CI and Gaster."
        },
        group_name = "godops_boosters"
    },
    config = { extra = 2, choose = 2 },
    cost = 66,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    group_key = "godops_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            5,
            5
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('godops_winner_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            key = "wdgaster",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "godops_winner_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "ci",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "godops_winner_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
