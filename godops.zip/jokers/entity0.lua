SMODS.Joker{ --ENTITY0
    key = "entity0",
    config = {
        extra = {
            Xmult = 11,
            chips = 1500,
            mult = 11,
            odds = 4,
            odds2 = 24,
            odds3 = 111,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'ENTITY0',
        ['text'] = {
            [1] = '{C:red}0000{}{C:blue}0000{C:green}0000{C:attention}0000{C:money}0000{C:gold}0000{C:inactive}0000{C:default}0000{C:hearts}0000{C:clubs}0000{C:diamonds}0000{C:spades}0000{C:tarot}0000{C:planet}0000{C:spectral}0000{C:enhanced}0000{C:common}0000{C:uncommon}0000{C:rare}0000{C:legendary}0000{C:edition}0000{C:dark_edition}0000{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}',
            [2] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5555,
    rarity = "godops_finality",
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["godops_godops_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'buf' and args.source ~= 'jud' 
          or args.source == 'sho' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    Xmult = card.ability.extra.Xmult,
                    message = "ENTITY0",
                    extra = {
                        chips = card.ability.extra.chips,
                            message = "ENTITY0",
                        colour = G.C.CHIPS,
                        extra = {
                            mult = card.ability.extra.mult,
                            message = "ENTITY0"
                        }
                        }
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_3f1d1f74', 1, card.ability.extra.odds, 'j_godops_entity0', false) then
              local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_godops_voidminion' })
                          if joker_card then
                              joker_card:set_edition("e_negative", true)
                              
                          end
                          
                          return true
                      end
                  }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "WEAKEST SUMMON.", colour = G.C.BLUE})
          end
                    if SMODS.pseudorandom_probability(card, 'group_1_ae5853ff', 1, card.ability.extra.odds2, 'j_godops_entity0', false) then
              local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_godops_botvw' })
                          if joker_card then
                              joker_card:set_edition("e_negative", true)
                              
                          end
                          
                          return true
                      end
                  }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "SECOND STRONGEST SUMMON.", colour = G.C.BLUE})
          end
                    if SMODS.pseudorandom_probability(card, 'group_2_c85f236a', 1, card.ability.extra.odds3, 'j_godops_entity0', false) then
              local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_godops_voidguardian' })
                          if joker_card then
                              joker_card:set_edition("e_negative", true)
                              
                          end
                          
                          return true
                      end
                  }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "STRONGEST SUMMON.", colour = G.C.BLUE})
          end
                        return true
                    end
                }
            end
        end
    end
}